#include <fcntl.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
  printf("Exploring glibc FILE structure safely\n\n");

  char *buf = malloc(0x500);

  printf("puts:%p heap:%p \n", &puts, buf);
  puts("Now reading into heap");

  read(STDIN_FILENO, buf, 0x500);

  puts("Now setting stderr->_chain");

  stderr->_chain = (struct _IO_FILE *)buf;

  puts("Bye!");

  exit(0);
}

// vim:sw=2
