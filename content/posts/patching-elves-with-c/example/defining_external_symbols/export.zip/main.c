extern void (*my_puts)(char *);

int main(void) {
  my_puts("Hello, world!");
}
